#include<stdio.h>
int main()
{
   int a=10,b,c;
   while(a>=0)
   {

       printf("%d\n",a);
       a-=1;
   }
    return 0;
}
