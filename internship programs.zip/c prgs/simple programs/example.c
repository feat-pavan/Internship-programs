#include<stdio.h>
int main()
{
    char name[10];
    char collage[10];
    char town[10];
    printf("enter the your name\n");
    scanf("%s",name);
    printf("enter your collage\n");
    scanf("%s",collage);
    printf("enter your town name\n");
    scanf("%s",town);
    printf("\n-----------------\n");
    printf("your name is %s\n",name);
    printf("your collage name is %s\n",collage);
    printf("your town is %s\n",town);
    return 0;
}
