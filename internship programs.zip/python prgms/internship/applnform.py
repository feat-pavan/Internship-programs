from tkinter import messagebox
import tkinter
from tkinter import ttk
from openpyxl import load_workbook

book=load_workbook("birth-details.xlsx")

sheet=book.active

'''sheet['A1']="Fname"
sheet['B1']="Lname"
sheet['C1']="Date"
sheet['D1']="Month"
sheet['E1']="Year"
sheet['F1']="Gender"'''
    


window=tkinter.Tk()
window.title("Facebook Login")
window.configure(bg="lavender")     #changes background color of window
window.geometry("1000x600")     #changes sizes of windows

def show():
    
    rows=((usfield.get()),(psfield.get()),(datecom.get()),(monthcom.get()),(yearcom.get()))
    for row in rows:
        #print(row)
        sheet.append(row)
        
        
    book.save("birth-details.xlsx")
    
 
def exitfun():
    y=messagebox.askyesno("Confirm",message="Are you sure wanna exit?")
    if y==1:
        window.destroy()  #destroy window
        
user=tkinter.Label(window,text="Fname", font=("Calibri (Body)",16), bg="lavender", fg="black")
user.place(x=68,y=250)
usfield=tkinter.Entry(width=23)
usfield.place(x=180,y=260)
        
user=tkinter.Label(window,text="Lname", font=("Calibri (Body)",16), bg="lavender", fg="black")
user.place(x=68,y=300)
psfield=tkinter.Entry(width=23)
psfield.place(x=180,y=310)
        
lbl=tkinter.Label(window,text="Birth Application Form", font=("Helvetica Neue",50), bg="lavender", fg="royal blue3")
lbl.pack()    #sets the label always in top midlle of window and it is default

label=tkinter.Label(window,text="Date", font=("Helvetica Neue",16), bg="lavender", fg="cornflower blue")
label.place(x=68,y=350)


datecom=ttk.Combobox(window)
datecom["value"]=(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31)
datecom.place(x=180,y=360)



fb=tkinter.Label(window,text="Month", font=("Calibri (Body)",16), bg="lavender", fg="blue")
fb.place(x=68,y=400)
monthcom=ttk.Combobox(window)
monthcom["value"]=("janauary","february","march","april","may","june","july","august","september","october","november","december")
monthcom.place(x=180,y=410)


fb=tkinter.Label(window,text="Year", font=("Calibri (Body)",16), bg="lavender", fg="black")
fb.place(x=68,y=450)
yearcom=ttk.Combobox(window)
yearcom["value"]=(1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012)
yearcom.place(x=180,y=460)

male=tkinter.Radiobutton(window,text="Male",value=1,bg="lavender")
male.place(x=150,y=500)

female=tkinter.Radiobutton(window,text="Female",value=2,bg="lavender")
female.place(x=220,y=500)

submit=tkinter.Button(window,text="Submit" ,bg="dodger blue", fg="white",font=("calibri" ,10),command=show)
submit.place(x=150,y=530)

cancel=tkinter.Button(window,text="cancel" ,bg="dodger blue", fg="white", font=("calibri" ,10),command=exitfun)
cancel.place(x=220,y=530)
window.mainloop()    #runs window for infinite times


