# -*- coding: utf-8 -*-

file=open("login.jpg","rb")
file1=open("theme.jpg","wb")
for i in file:
    file1.write(i)
    
print("finished")
file.close()