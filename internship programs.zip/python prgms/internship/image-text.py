import pytesseract
from PIL import Image
file=open("imagedata.txt","w")

pytesseract.pytesseract.tesseract_cmd="C:/Program Files (x86)/Tesseract-OCR/tesseract"

img=Image.open("textimage.png")

text=pytesseract.image_to_string(img)
for i in text:
    file.write(i)
    
file.close()    
print("Done")