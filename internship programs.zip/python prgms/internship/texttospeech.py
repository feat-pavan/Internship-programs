from gtts import gTTS
import os

mydata="welcome to machine learning"
speech=gTTS(text=mydata,lang='en',slow=True)
speech.save("pythonvoice.mp3")
os.system("pythonvoice.mp3")