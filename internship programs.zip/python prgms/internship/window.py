from tkinter import messagebox
import tkinter

window=tkinter.Tk()
window.title("Facebook Login")
window.configure(bg="lavender")     #changes background color of window
window.geometry("1000x600")     #changes sizes of windows

def info1():
    uname="pavan"
    pswd="pavan123"
    a=""  #nothing 
        
    if userfield.get()==uname and pasfield.get()==pswd:
        messagebox.showinfo("Notification","Login sucessfull..!!")
        
    elif userfield.get()==a and pasfield.get()==a:
        messagebox.showinfo("Notification","fields are empty..")
        
    elif userfield.get()==uname and pasfield.get()==a:
        messagebox.showinfo("Notification","Password field is empty..")
        
    elif userfield.get()==a and pasfield.get()==pswd:
        messagebox.showinfo("Notification","username is empty..")
        
    else:
        messagebox.showinfo("Notification","Incorrect username and password")
       
    
        
def exitfun():
    y=messagebox.askyesno("Confirm",message="Are you sure wanna exit?")
    if y==1:
        window.destroy()  #destroy window
        

label=tkinter.Label(window,text="facebook", font=("Helvetica Neue",60), bg="lavender", fg="cornflower blue")
label.place(x=68,y=300)


fb=tkinter.Label(window,text="Welcome to facebook", font=("Calibri (Body)",20), bg="lavender", fg="blue")
fb.place(x=68,y=400)

fb=tkinter.Label(window,text="Lets's connect people", font=("Calibri (Body)",20), bg="lavender", fg="black")
fb.place(x=68,y=440)

usrlbl=tkinter.Label(window,text="Username:", font=("Product Sans",15), bg="lavender",fg="black")
usrlbl.place(x=700,y=320)
userfield=tkinter.Entry(window,width=20)    #usr entrry
userfield.place(x=800,y=325)


paslbl=tkinter.Label(window,text="Password:", font=("Product Sans",15), bg="lavender",fg="black")
paslbl.place(x=700,y=360)
pasfield=tkinter.Entry(window,width=20)    #passwd entry
pasfield.place(x=800,y=364)


submit=tkinter.Button(window,text="Login" ,bg="dodger blue", fg="white",font=("calibri" ,15), command=info1)
submit.place(x=790,y=420)

cancel=tkinter.Button(window,text="cancel" ,bg="dodger blue", fg="white", font=("calibri" ,15),command=exitfun)
cancel.place(x=880,y=420)
window.mainloop()    #runs window for infinite times

