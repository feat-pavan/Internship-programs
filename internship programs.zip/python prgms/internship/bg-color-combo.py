from tkinter import messagebox
import tkinter
from tkinter import ttk

window=tkinter.Tk()
window.title("Facebook Login")
    #changes background color of window
window.geometry("1000x600")     #changes sizes of windows

def show():
    window.configure(bg=datecom.get())
    

def exitfun():
    y=messagebox.askyesno("Confirm",message="Are you sure wanna exit?")
    if y==1:
        window.destroy()  #destroy window
        
        
lbl=tkinter.Label(window,text="Let's Pick a color", font=("Helvetica Neue",50), bg="lavender", fg="royal blue3")
lbl.pack()    #sets the label always in top midlle of window and it is default

label=tkinter.Label(window,text="Pick here", font=("Helvetica Neue",20), bg="lavender", fg="cornflower blue")
label.place(x=68,y=350)


datecom=ttk.Combobox(window)
datecom["value"]=("hot pink","skyblue","lightgreen","cyan3","lightblack","tomato3","oliver")
datecom.place(x=200,y=360)



submit=tkinter.Button(window,text="Change color" ,bg="dodger blue", fg="white",font=("calibri" ,15),command=show)
submit.place(x=700,y=420)

cancel=tkinter.Button(window,text="cancel" ,bg="dodger blue", fg="white", font=("calibri" ,15),command=exitfun)
cancel.place(x=880,y=420)
window.mainloop()    #runs window for infinite times


