import speech_recognition as sr
import time

r=sr.Recognizer()

with sr.Microphone() as source:
    print("Speak something for 3 seconds")
    audio=r.listen(source,1)
    time.sleep(3)     #seconds
    print("Enough")
    
try:
    text=r.recognize_google(audio)
    print("you said: "+text)
    
except:
    print("I cant hear you bruh....!!!")