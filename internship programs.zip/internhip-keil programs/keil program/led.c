#include<reg51.h>
sbit led=P1^0;
void delay(int x);
void main()

{
while(1)
{
led=1;
delay(100);
led=0;
delay(100);
}
}

void delay(int x)
{
int i,j;
for(i=0;i<x;i++)
for(j=0;j<1275;j++);
}