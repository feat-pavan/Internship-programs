#include<reg51.h>
#define seven P2
sbit led=P1^0;

void delay(int x);
int main()
{
	int i;
	char sv[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x80,0xc6,0xc0,0x86,0x8e};
	while(1)
	{
		for(i=0;i<sizeof(sv);i++)
		{
			seven = sv[i];
			delay(50);
			
			}
	}
}

void delay(int x)
{
	int i,j;
	for(i=0;i<x;i++)
	for(j=0;j<1275;j++);
}
		
		