#include<reg51.h>
#define lcd P1
sbit rs=P2^0;
sbit en=P2^1;

void lcdcmd(char x);
void lcddata(char y);
void enable();
void init1();
void init2();
void delay(int d);

void main()
{
	while(1)
	{
			init1();
			lcddata('W');
			delay(50);
			lcddata('E');
			delay(50);
			lcddata('L');
			delay(50);
			lcddata('C');
			delay(50);
			lcddata('O');
			delay(50);
			lcddata('M');
			delay(50);
			lcddata('E');
			delay(50);
			lcddata(' ');
			delay(50);
			lcddata('T');
			delay(50);
			lcddata('O');
			delay(50);
		
		init2();
			lcddata('L');
			delay(50);
			lcddata('O');
			delay(50);
			lcddata('G');
			delay(50);
			lcddata('I');
			delay(50);
			lcddata('N');
			delay(50);
			lcddata('W');
			delay(50);
			lcddata('A');
			delay(50);
			lcddata('R');
			delay(50);
			lcddata('E');
			delay(50);
			
			
		
		
		
	}
}

void lcdcmd(char x)
{
	rs=0;  // register selector set to command mode
	lcd=x;
	enable();
}

void lcddata(char y)
{
	rs=1;   //register selector set to data mode
	lcd=y;
	enable();
}

void enable()
{
	en=1;
	delay(10);
	en=0;
	delay(10);
}

void init1()
{
	lcdcmd(0x0e);  //turn ON lcd display and curzor
	lcdcmd(0x38);  // 16x2 matrix mode
	lcdcmd(0x06);  //incremanting curzor from left to right
	lcdcmd(0x01);   // clearing data
	lcdcmd(0x80);  // first row first coloumn
}

void init2()
{
	lcdcmd(0x0e);  //turn ON lcd display and curzor
	lcdcmd(0x38);  // 16x2 matrix mode
	lcdcmd(0x06);  //incremanting curzor from left to right
	//lcdcmd(0x01);   // clearing data
	lcdcmd(0xc0);  // second row first coloumn
}

void delay(int d)
{
	int i,j;
	for(i=0;i<d;i++)
	for(j=0;j<1275;j++);
}