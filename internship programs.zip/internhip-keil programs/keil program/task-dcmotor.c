#include<reg51.h>
sbit in1=P1^0;   // pin1 of the driver
sbit in2=P1^1;    // pin2 of the driver
sbit led1=P1^2;   // green led
sbit led2=P1^3;   // red led
sbit swt=P1^4;   //switch

void main()
{
	while(1)
	{
		 if(swt==0)
		{
			led1=0;  //green
			led2=1;  //red
			in1=0;
			in2=0;
		}
		else if(swt==1)
		{
			in1=0;  // clockwise
			in2=1;
			led1=1;// green
			led2=0; // red
		}
	}
}