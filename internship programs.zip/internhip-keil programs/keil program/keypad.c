#include<reg51.h>
#define lcd P1
#define display P0
sbit led=P3^7;
sbit r1=P3^0;
sbit r2=P3^1;
sbit r3=P3^2;
sbit r4=P3^3;
sbit c1=P3^4;
sbit c2=P3^5;
sbit c3=P3^6;

sbit rs=P2^0;
sbit en=P2^1;

void lcdcmd(char x);
void lcddata(char y);
void enable();
void init();

void delay(int d);

void main()
{ 
	int i=0;
	init();
	led=0;
	while(1)
	{
		//init();
		r1=0;
		if(c1==0)
		{
			lcddata('1');
			display=0xf9;
			delay(30);
			for(i=0;i<1;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		if(c2==0)
		{
			lcddata('2');
			display=0xa4;
			delay(30);
			for(i=0;i<2;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
			
		}
		if(c3 ==0)
		{
			lcddata('3');
			display=0xb0;
			delay(30);
			for(i=0;i<3;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		r1=1;
		r2=0;
		if(c1 ==0)
		{
			lcddata('4');
			display=0x99;
			delay(30);
			for(i=0;i<4;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		if(c2 ==0)
		{
			lcddata('5');
			display=0x92;
			delay(30);
			for(i=0;i<5;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		if(c3 ==0)
		{
			lcddata('6');
			display=0x82;
			delay(30);
			for(i=0;i<6;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		r2=1;
		r3=0;
		if(c1 ==0)
		{
			lcddata('7');
			display=0xf8;
			delay(30);
			for(i=0;i<7;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		if(c2 ==0)
		{
			lcddata('8');
			display=0x80;
			delay(30);
			for(i=0;i<8;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		if(c3 ==0)
		{
			lcddata('9');
			display=0x90;
			delay(30);
			for(i=0;i<9;i++)
			{
				led=1;
				delay(20);
				led=0;
				delay(20);
			}
		}
		r3=1;
		r4=0;
		if(c1 ==0)
		{
			lcddata('*');
			delay(30);
		}
		if(c2 ==0)
		{
			lcddata('0');
			display=0xc0;
			delay(30);
		}
		if(c3 ==0)
		{
			lcddata('#');
			delay(30);
		}
		r4=1;
		
		
	}
}

void lcdcmd(char x)
{
	rs=0;  // register selector set to command mode
	lcd=x;
	enable();
}

void lcddata(char y)
{
	rs=1;   //register selector set to data mode
	lcd=y;
	enable();
}

void enable()
{
	en=1;
	delay(10);
	en=0;
	delay(10);
}

void init()
{
	lcdcmd(0x0e);  //turn ON lcd display and curzor
	lcdcmd(0x38);  // 16x2 matrix mode
	lcdcmd(0x06);  //incremanting curzor from left to right
	//lcdcmd(0x01);   // clearing data
	lcdcmd(0x80);  // first row first coloumn
}



void delay(int d)
{
	int i,j;
	for(i=0;i<d;i++)
	for(j=0;j<1275;j++);
}