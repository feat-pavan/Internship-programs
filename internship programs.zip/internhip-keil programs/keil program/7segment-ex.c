#include<reg51.h>
#define seven P2
sbit swt=P1^0;

void delay(int x);
int main()
{
	int i=0,j,k,m;
	char sv[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92};
	while(1)
	{
		for(i=0;i<sizeof(sv);i++)
		{
			for(k=0;k<sizeof(sv);k++)
			{ m=k;
			if(swt==0 && i==m)
			{
				seven=sv[i];
				delay(30);
				
			}
		}
		}
	}
}


void delay(int x)
{
	int i,j;
	for(i=0;i<x;i++)
	for(j=0;j<1275;j++);
}
		
		