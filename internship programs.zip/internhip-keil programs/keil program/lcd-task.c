#include<reg51.h>
#include<string.h>
#define lcd P1
sbit rs=P2^0;
sbit en=P2^1;

void lcdcmd(char x);
void lcddata(char y);
void enable();
void string(char d[]);
void init();

void delay(int d);

void main()
{
	
		init();	
		lcdcmd(0x80);
		
		string("Welcome to");
		delay(50);
	
	
		while(1){
		init();
		lcdcmd(0xc0);
		string("loginware");
		delay(50);
		while(1)
		{
			
			lcdcmd(0x1c);
		
	}
}}

void string(char d[])
{
	int i,j;
	
	for(i=0;i<=strlen(d);i++)
	{
		lcddata(d[i]);
		
	}
}


void lcdcmd(char x)
{
	rs=0;  // register selector set to command mode
	lcd=x;
	enable();
}

void lcddata(char y)
{
	rs=1;   //register selector set to data mode
	lcd=y;
	enable();
}

void enable()
{
	en=1;
	delay(10);
	en=0;
	delay(10);
}

void init()
{
	lcdcmd(0x0e);  //turn ON lcd display and curzor
	lcdcmd(0x38);  // 16x2 matrix mode
	lcdcmd(0x06);  //incremanting curzor from left to right
	//lcdcmd(0x01);   // clearing data
	//lcdcmd(0x80);  // first row first coloumn
}



void delay(int d)
{
	int i,j;
	for(i=0;i<d;i++)
	for(j=0;j<1275;j++);
}