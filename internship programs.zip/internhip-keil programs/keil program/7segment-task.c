#include<reg51.h>
#define seven P2
sbit swt=P1^0;

void delay(int x);
int main()
{
	int i=0;
	//char sv[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92};
	while(1)
	{
		if(swt==0 && i==0)
		{
			seven=0xc0;
			i++;
			delay(50);
		}
	else if(swt==0 && i==1)
	{
		seven=0xf9;
		i++;
		delay(50);
	}
	else if(swt==0 && i==2)
	{
		seven=0xa4;
		i++;
		delay(50);
	}
	else if(swt==0 && i==3)
	{
		seven=0xb0;
		i++;
		delay(50);
	}
	else if(swt==0 && i==4)
	{
		seven=0x99;
		i=0;
		delay(50);
	}
	
}

	
	
}

void delay(int x)
{
	int i,j;
	for(i=0;i<x;i++)
	for(j=0;j<1275;j++);
}
		
		