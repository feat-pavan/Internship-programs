#include<reg51.h>
sbit dcm1=P1^0;   // 1 dc motor
sbit dcm2=P1^1;
sbit dcm3=P1^2;    // 2nd dc motor
sbit dcm4=P1^3;

void delay(int d)
{
	int i,j;
	for(i=0;i<d;i++)
	for(j=0;j<1275;j++);
}

 void main()
 {
	for(;;)
	{
		dcm1=0;  // dc1 anticlockwise 
		dcm2=1;
		dcm3=1;  //dc2 clockwise direction
		dcm4=0;
		delay(300);
		dcm1=1;  // dc1 clockwise direction
		dcm2=0;
		dcm3=0;
		dcm4=1;   //dc2 anticlckwise 
		delay(300);
		}
	}
	
