#include<reg51.h>
sbit led1=P1^0;
sbit led2=P1^1;
sbit led3=P1^2;
void delay(int x);
void main()

{
while(1)
{
led1=1;
	delay(50);
	led1=0;
	delay(100);
		
	led2=1;
	delay(50);
	led2=0;
	delay(100);
	
	led3=1;
	delay(50);
	led3=0;
	delay(100);
}
}

void delay(int x)
{
int i,j;
for(i=0;i<x;i++)
for(j=0;j<1275;j++);
}