#include<reg51.h>
sbit led1=P1^0;
sbit led2=P1^1;
sbit swt1=P1^2;
sbit swt2=P1^3;

void delay(int d);
void main()
{
	int i=0;
	led1=0;
	led2=0;
	while(1)
	{
		if(swt1==0)
		{
			led1=1;
			led2=0;
			
			//delay(50);
		}
		 if(swt2==0)
		{
			led1=0;
			led2=1; 
		
			//delay(50);
		}
	}
}
void delay(int d)
{
	int i,j;
	for(i=0;i<d;i++)
	for(j=0;j<1275;j++);
}