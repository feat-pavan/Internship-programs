#include<windows.h>
#include<GL/glut.h>

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3i(1,1,0);
    glBegin(GL_POLYGON);
    glVertex2i(5,10);
    glEnd();
}
void init()
{
    glClearColor(1.0,1.0,1.0,1.0);

}
int main(int argc,char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(500,500);
    glutCreateWindow("my programs");
   // init();
    glutDisplayFunc(display);
    glutMainLoop();
}
