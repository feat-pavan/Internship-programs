#include<windows.h>
#include<stdio.h>
#include<GL/glut.h>
GLfloat a=0,b=0,c=0,d=0,e=0;
void update(int value) //takeoff function
{
	a+=20.0;	//Plane position takeoff on x axis
	b-=10.0;	//Road Strip backward movement
	c+=15;	//take off at certain angle on y axis
	if(b<=-78.0)// moving of run way
		b=0.0;
	glutPostRedisplay();
	glutTimerFunc(100,update,0);//delay
}

void display(void)
{
glClear(GL_COLOR_BUFFER_BIT);
//runway();
glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);//rectangular body
//glVertex2f(0.0,30.0);
glVertex2f(0.0,55.0);
//glVertex2f(135.0,55.0);
glVertex2f(135.0,30.0);
glEnd();
glPopMatrix();
glutSwapBuffers();
}

void myinit()
{

glClearColor(0.0f,0.0f,1.0f,0.0f);
glColor3f(0.0,1.0,0.0);
glPointSize(1.0);
glMatrixMode(GL_PROJECTION);
//glLoadIdentity();
gluOrtho2D(0.0,499.0,0.0,499.0);

}

int main(int argc, char* argv[])
{
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
glutInitWindowSize(500.0,500.0);
glutInitWindowPosition(0,0);
glutCreateWindow("Airplane Takeoff computer graphics projects");
glutDisplayFunc(display);
myinit();
//glutTimerFunc(100,update,0);
glutMainLoop();
return 0;
}
