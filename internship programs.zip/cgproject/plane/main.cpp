#include<windows.h>
#include<stdio.h>
#include<GL/glut.h>
GLfloat a=0,b=0,c=250,d=0,e=0;
void runway();
int main(int argc, char* argv[]);

void update(int value)
{


	a+=20.0;	//Plane position takeoff on x axis         takeoff from vertical upaand downward direction
	b-=10.0;	//speed of Road Strip backward movement
	c+=15;	//take off at certain angle on y axis      helpfull for plane takeoff and landing
	if(b<=-78.0)// moving of run way
		b=0.0;
	glutPostRedisplay();
	glutTimerFunc(110,update,0);//delay
}

void update1(int value)
{


	a+=20.0;	//Plane position takeoff on x axis         takeoff from vertical upaand downward direction
	b-=10.0;	//speed of Road Strip backward movement
	c-=15;	//take off at certain angle on y axis      helpfull for plane takeoff and landing
	if(b<=-78.0)// moving of run way
		b=0.0;
	glutPostRedisplay();
	glutTimerFunc(100,update1,0);//delay
}


void display(void)
{

glClear(GL_COLOR_BUFFER_BIT);
runway();
glPushMatrix(); //integrates all parts

glTranslated(a,c,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);//rectangular body
glVertex2f(0.0,30.0);
glVertex2f(0.0,55.0);
glVertex2f(135.0,55.0);
glVertex2f(135.0,30.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);//upper triangle construction plane
glVertex2f(135.0,55.0);
glVertex2f(150.0,50.0);
glVertex2f(155.0,45.0);
glVertex2f(160.0,40.0);
glVertex2f(135.0,40.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(0.0,0.0,0.0);
glBegin(GL_LINE_LOOP);//outline of upper triangle plane
glVertex2f(135.0,55.0);
glVertex2f(150.0,50.0);
glVertex2f(155.0,45.0);
glVertex2f(160.0,40.0);
glVertex2f(135.0,40.0);
glEnd();
glPopMatrix();


glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,0.0,0.0);
glBegin(GL_POLYGON);//lower triangle
glVertex2f(135.0,40.0);
glVertex2f(160.0,40.0);
glVertex2f(160.0,37.0);
glVertex2f(145.0,30.0);
glVertex2f(135.0,30.0);
glEnd();
glPopMatrix();


glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,0.0,0.0);
glBegin(GL_POLYGON);//back wing
glVertex2f(0.0,55.0);
glVertex2f(0.0,80.0);
glVertex2f(10.0,80.0);
glVertex2f(40.0,55.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,0.0,0.0);
glBegin(GL_POLYGON);//left side wing
glVertex2f(65.0,55.0);
glVertex2f(50.0,70.0);
glVertex2f(75.0,70.0);
glVertex2f(90.0,55.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(a,c,0.0);
glColor3f(1.0,0.0,0.0);
glBegin(GL_POLYGON);//rightside wing
glVertex2f(70.0,40.0);
glVertex2f(100.0,40.0);
glVertex2f(80.0,15.0);
glVertex2f(50.0,15.0);

glEnd();

glPopMatrix();
if(a>500.0)//window position during take off
{
	a=0.0;
	b=0.0;
}
glFlush();
glutSwapBuffers();
}



void runway()
{

glColor3f(0.0,0.0,0.0);
glBegin(GL_POLYGON);//black road
glVertex2f(0.0,0.0);
glVertex2f(0.0,100.0);
glVertex2f(500.0,100.0);
glVertex2f(500.0,0.0);
glEnd();
glPopMatrix();



glPushMatrix();
glTranslated(b,0.0,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);//white strips on road
glVertex2f(0.0,40.0);
glVertex2f(8.0,60.0);
glVertex2f(58.0,60.0);
glVertex2f(50.0,40.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(b,0.0,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);
glVertex2f(100.0,40.0);
glVertex2f(108.0,60.0);
glVertex2f(158.0,60.0);
glVertex2f(150.0,40.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(b,0.0,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);
glVertex2f(200.0,40.0);
glVertex2f(208.0,60.0);
glVertex2f(258.0,60.0);
glVertex2f(250.0,40.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(b,0.0,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);
glVertex2f(300.0,40.0);
glVertex2f(308.0,60.0);
glVertex2f(358.0,60.0);
glVertex2f(350.0,40.0);
glEnd();
glPopMatrix();

glPushMatrix();
glTranslated(b,0.0,0.0);
glColor3f(1.0,1.0,1.0);
glBegin(GL_POLYGON);
glVertex2f(400.0,40.0);
glVertex2f(408.0,60.0);
glVertex2f(458.0,60.0);
glVertex2f(450.0,40.0);
glEnd();
glPopMatrix();
}



void myinit()
{

glClearColor(0.0f,0.0f,1.0f,0.0f); //background color
glColor3f(1.0,0.0,0.0);
glPointSize(1.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0,450.0,0.0,499.0);   //size of plane and stuff

}

void takeoff(int option)
{
    if(option==1)
    {
     exit(0);
    }

}

int main(int argc, char* argv[])
{

    int menu;
     printf("\n\n\n\n");
    printf("\t\t\t\t\tWELCOME TO FLYING PLANE PROJECT\n\n");
    printf("\t\t\t\t\tProject by,\n");
    printf("\t\t\t\t\t\tPavan P\n");
    printf("\t\t\t\t\t\tLavanya SP\n");

    printf("\n\n\n\n");
    printf("\t\t\t---------------------------------choose option---------------------------------\n");
    printf("\n\n\t\t\t1.plane takeoff\n\t\t\t2.plane landing\n\t\t\t3.exit\n");
    scanf("%d",&menu);

    switch(menu)
    {
    case 1:
        {


        glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
glutInitWindowSize(500,500);
glutInitWindowPosition(0,0);
glutCreateWindow("Airplane Takeoff computer graphic Screen");
glutDisplayFunc(display);
myinit();
glutCreateMenu(takeoff);
glutAddMenuEntry("Exit",1);
glutAttachMenu(GLUT_RIGHT_BUTTON);

glutTimerFunc(100,update,0);
glutMainLoop();
return 0;
        break;
    }
    case 2:
        {
            glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
glutInitWindowSize(500,500);
glutInitWindowPosition(0,0);
glutCreateWindow("Airplane Landing computer graphic Screen");
glutDisplayFunc(display);
myinit();
glutCreateMenu(takeoff);
glutAddMenuEntry("Exit",1);

glutAttachMenu(GLUT_RIGHT_BUTTON);

glutTimerFunc(100,update1,0);
glutMainLoop();
return 0;
break;
        }
    case 3:
        {
            exit(0);
            break;
        }
        default:
        {
            printf("invalid choice");
            break;
        }
    }
}
