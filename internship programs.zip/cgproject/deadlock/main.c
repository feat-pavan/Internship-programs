#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

int k=0,output[10],d=0,t=0,ins[5],i,avail[5],allocated[10][5],need[10][5],MAX[10][5],req[5],pno = 0,reqpno = 0,P[10];
int j,rz, count=0, prevItr = 0, currItr = 0, ch;



void bankers()
{
    A: d=-1;   //label
 for(i=0;i <pno;i++)
 {
   count=0; t=P[i];

   //calculate need matrix for current process
   for(j=0;j<rz;j++)
  {
    need[t][j] = MAX[t][j]-allocated[t][j];
    //if need is more than MAX defined
    if (need[t][j] < 0)
    {
        printf("Need exceeding MAX!");
        exit(0);
    }

    // if the process can currently execute?
    if(need[t][j]<=avail[j])
    count++;
  }


   if(count==rz)
  {
   //record the completed process
   output[k++]=P[i];

   //give back the resources
   for(j=0;j<rz;j++)
   avail[j]+=allocated[t][j];
  }
   else
  {

    P[++d]=P[i];
  }
 }
 prevItr = currItr;
 currItr = d;

  //check if none of the process gets completed in two successive iterations
  if(prevItr == currItr)
  {
   printf("It is not a safe sequence");
   getch();
  printf("There is a Deadlock!");
  exit(0);
  }

  else if(d!=-1)
  {
   pno=d+1;
   goto A;
  }
  printf("Safe Sequence is : \n");
  printf("\t <");
  for(i=0;i<k;i++)
  printf(" P[%d] ",output[i]);
  printf(">");
}

void resReq()
{
    printf("Enter the process number requesting the resources: ");
    scanf("%d",&reqpno);
    printf("Enter the P[%d] request matrix: \n", reqpno);
    for(i=0; i<rz; i++)
    scanf("%d",&req[i]);

     for(i=0; i<rz; i++)
     {   //removing resources from available
         avail[i]-= req[i];
         if(avail[i]<0){
            printf("Resource request is not possible!");
            exit(0);}
        // adding resources to allocated
        allocated[reqpno][i]+= req[i];
     }
     bankers();

}

int main()
{


   printf("\n Enter the number of resources : ");
   scanf("%d", &rz);


   printf("\n Enter the available matrix : \n");
   for(i=0;i<rz;i++)
     scanf("%d",&avail[i]);

   printf("\n Enter the number of processes : ");
   scanf("%d", &pno);


   printf("\n Enter the allocation matrix \n     ");

   for(i=0;i<rz;i++)
    printf(" %c",(i+97));

     printf("\n");

     for(i=0;i <pno;i++)
     {
      P[i]=i;
      printf("P[%d]  ",P[i]);
      for(j=0;j<rz;j++)
      {
       scanf("%d",&allocated[i][j]);
      }
     }


     printf("\nEnter the MAX matrix :\n");
      for(i=0;i <pno;i++)
      {
       printf("P[%d]  ",i);
       for(j=0;j<rz;j++)
	scanf("%d", &MAX[i][j]);
      }

      printf("\n");

      printf(" 1)Bankers \n 2)Resource Request \n Enter your choice: ");
      scanf("%d",&ch);

      switch(ch)
      {
          case 1: bankers();
                  break;
          case 2: resReq();
                  break;
          default: printf("Wrong choice!");

      }

      return 0;


}
